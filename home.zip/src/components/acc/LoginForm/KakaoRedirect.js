<Route path="/auth" element={<Redirect />} />
          {/*kakao Redirect 화면 */}