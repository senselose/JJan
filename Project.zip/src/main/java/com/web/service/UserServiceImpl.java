package com.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.web.repository.UserRepository;
import com.web.user.User;

@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Override
    @Transactional
    public void registerUser(User user) {
        logger.info("Registering user: {}", user);
        userRepository.save(user);
    }

    @Override
    public User findByUserIdAndUserPassword(Long userId, String userPassword) {
        return userRepository.findByUserIdAndUserPassword(userId, userPassword);
    }

    @Override
    public boolean isUserIdExists(Long userId) {
        return userRepository.existsByUserId(userId);
    }

    @Override
    public boolean isUserNickNameExists(String userNickName) {
        return userRepository.existsByUserNickNameCustom(userNickName);
    }

    @Override
    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }
}
