package com.web.repository;

public interface UserRepositoryCustom {
    boolean existsByUserNickNameCustom(String userNickName);
}
