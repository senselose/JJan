package com.web.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepositoryCustomImpl implements UserRepositoryCustom {

    @Autowired
    private EntityManager entityManager;

    @Override
    public boolean existsByUserNickNameCustom(String userNickName) {
        String queryStr = "SELECT COUNT(*) FROM user WHERE user_nickname = :userNickName";
        Query query = entityManager.createNativeQuery(queryStr);
        query.setParameter("userNickName", userNickName);
        long count = ((Number) query.getSingleResult()).longValue();
        return count > 0;
    }
}
