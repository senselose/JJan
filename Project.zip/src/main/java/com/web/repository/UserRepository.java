package com.web.repository;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.web.user.User;

//@Repository
//public interface UserRepository extends JpaRepository<User, Long> {
//	
//	boolean existsByUserId(Long userId);     // 회원가입시 아이디 중복불가 
//	 
//	boolean existsByUserNickName(String userNickName); // 회원가입시 닉네임 중복 불가
//	
//	User findByUserIdAndUserPassword(Long userId, String userPassword);
//
//	Optional<User> findByUserName(String userName);
//	
//
//
//
//}

@Repository
public interface UserRepository extends JpaRepository<User, Long>, UserRepositoryCustom {
    boolean existsByUserId(Long userId);
    User findByUserIdAndUserPassword(Long userId, String userPassword);
    Optional<User> findByUserName(String userName);
}
