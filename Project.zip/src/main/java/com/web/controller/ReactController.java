//package com.web.controller;
//
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@CrossOrigin(origins = "http://localhost:3000") // 특정 도메인에 대해 CORS 허용
//public class ReactController {
//	
//	@GetMapping("/api/hello")
//	public String hello() {
//		return "안녕 스프링부트!";
//	}
//	
//	
//}
