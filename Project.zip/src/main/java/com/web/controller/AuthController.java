package com.web.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.web.security.JwtTokenProvider;
import com.web.service.EmailService;
import com.web.service.UserService;
import com.web.user.User;

@RestController
@RequestMapping("api/auth")
public class AuthController {
	
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtTokenProvider tokenProvider;
	
	@Autowired
	private EmailService emailService;
	
	// 아이디 중복 확인
    @GetMapping("/checkUserId")
    public Map<String, Boolean> checkUserId(@RequestParam("userId") String userIdStr) {
        Map<String, Boolean> response = new HashMap<>();
        try {
            Long userId = Long.parseLong(userIdStr);  // String을 Long으로 변환
            boolean exists = userService.isUserIdExists(userId);
            response.put("exists", exists);
        } catch (NumberFormatException e) {
            response.put("exists", false);
        }
        return response;
    }
	
	// 닉네임 중복 확인
	@GetMapping("/checkUserNickName")
	public Map<String, Boolean> checkUserNickName(@RequestParam("userNickName") String userNickName) {
		boolean exists = userService.isUserNickNameExists(userNickName);
		Map<String, Boolean> response = new HashMap<>();
		response.put("exists", exists);
		return response;
	}
	
	@PostMapping("/login")
	public Map<String, String> authenticateUser(@RequestBody Map<String, String> loginRequest) {
		Map<String, String> response = new HashMap<>();
		try {
			Long userId = Long.valueOf(loginRequest.get("userId"));
			String password = loginRequest.get("userPassword");
			
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(userId, password));
			String token = tokenProvider.generateToken(authentication.getName());
			
			response.put("token", token);
			response.put("message", "User authenticated successfully");
		} catch (AuthenticationException e) {
			response.put("message", "Invalid username or password");
		} catch (NumberFormatException e) {
			response.put("message", "Invalid user ID format");
		}
		
		return response;
	}
	
	@PostMapping("/sendVerificationCode")
	public Map<String, String> sendVerificationCode(@RequestBody Map<String, String> request) {
		String email = request.get("email");
		String provider = request.get("provider"); //이메일 제공자
		emailService.sendVerificationCode(email, provider);
		
		Map<String, String> response = new HashMap<>();
		response.put("message", "인증번호가 이메일로 전송되었습니다.");
		return response;
	}
	
	@PostMapping("/verifyCode")
	public Map<String, Boolean> verifyCode(@RequestBody Map<String, String> request) {
		String email = request.get("email");
		String code = request.get("code");
		boolean isValid = emailService.verifyCode(email, code);
		
		Map<String, Boolean> response = new HashMap<>();
		response.put("isValid", isValid);
		return response;
	}
	
	@PostMapping("/checkVerificationStatus")
	public Map<String, Boolean> checkVerificationStatus(@RequestBody Map<String, String> request) {
		String email = request.get("email");
		boolean isVerified = emailService.isVerified(email);
		
		Map<String, Boolean> response = new HashMap<>();
		response.put("isVerified", isVerified);
		return response;
	}
	
	// 회원가입 정보 입력
	@PostMapping("/register")
	public String register(@RequestBody Map<String, String> userRequest, Model model) throws ParseException {
		
		String userIdStr = userRequest.get("userId");
		if (userIdStr == null || userIdStr.isEmpty()) {
			model.addAttribute("error", "User ID is required");
			return "registerForm";
		}
		
		Long userId = Long.parseLong(userRequest.get("userId"));
		User user = new User();
		user.setUserId(userId);
		user.setUserName(userRequest.get("userName"));
		user.setUserNickName(userRequest.get("userNickName"));
		user.setUserPassword(userRequest.get("userPassword"));
		user.setUserEmail(userRequest.get("userEmail"));
		user.setUserDomain(userRequest.get("userDomaim"));
		
		String userBirthStr = userRequest.get("userBirth");
		SimpleDateFormat dataFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date userBirth = dataFormat.parse(userBirthStr);
		user.setUserBirth(userBirth);
		
		user.setUserPhoneNum(userRequest.get("userPhoneNum"));
		user.setUserProfileImage(userRequest.get("userProfileImage"));
		
		if (!emailService.isVerified(user.getUserEmail())) {
			model.addAttribute("error", "이메일 인증을 완료해야합니다.");
			return "registerForm";
		}
		
		userService.registerUser(user);
		return "registerSuccess";
	}
	
	@GetMapping("/user/{userId}")
	public ResponseEntity<User> getUserById(@PathVariable Long userId) {
		User user = userService.getUserById(userId);
		if (user != null) {
			return ResponseEntity.ok(user);
		} else {
			return ResponseEntity.notFound().build();
				
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
