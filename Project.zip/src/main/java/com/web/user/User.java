package com.web.user;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "users")
public class User {
	
	@Id
	@Column(name = "user_id")
	private Long userId;
	
	
	@Column(name = "user_name", nullable = false)
	private String userName;
	
	@Column(name = "user_nickname", unique = true, nullable = false)
	private String userNickName;
	
	@Column(name = "user_password", nullable = false)
	private String userPassword;
	
	@Column(name = "user_email", nullable = false)    
	private String userEmail;
	
	@Column(name = "user_domain", nullable = false)
	private String userDomain;
	
	@Column(name = "user_birth", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date userBirth;
	
	@Column(name = "user_phone_num", nullable = false)
	private String userPhoneNum;
	
	@Column(name = "user_profile_image")
	private String userProfileImage;
	
	
	
	
	
}
