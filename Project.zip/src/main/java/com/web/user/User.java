package com.web.user;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "users")
public class User {
    @Id
    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "USER_NAME", nullable = false)
    private String userName;

    @Column(name = "USER_NICKNAME", nullable = false)
    private String userNickName;

    @Column(name = "USER_PASSWORD", nullable = false)
    private String userPassword;

    @Column(name = "USER_EMAIL", nullable = false)
    private String userEmail;

    @Column(name = "USER_DOMAIN", nullable = false)
    private String userDomain;

    @Temporal(TemporalType.DATE)
    @Column(name = "USER_BIRTH", nullable = false)
    private Date userBirth;

    @Column(name = "USER_PHONE_NUM", nullable = false)
    private String userPhoneNum;

    @Column(name = "USER_PROFILE_IMAGE")
    private String userProfileImage;
}
