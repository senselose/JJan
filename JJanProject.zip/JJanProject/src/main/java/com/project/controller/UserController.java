package com.project.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.service.UserService;
import com.project.user.User;

@Validated
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/")
    public String home(HttpServletRequest request, Model model) {
        HttpSession session = request.getSession(false);
        if (session != null && session.getAttribute("userId") != null) {
            Long userId = (Long) session.getAttribute("userId");
            model.addAttribute("sessionUserId", userId);
        }
        return "index";
    }

    @GetMapping("/loginForm")
    public String loginForm() {
        return "loginForm"; // login html 반환
    }

    @PostMapping("/login")
    public String login(@RequestBody Map<String, String> loginRequest,
                        HttpSession session,
                        Model model) {
    	try {
            Long userId = Long.valueOf(loginRequest.get("userId"));
            String userPassword = loginRequest.get("userPassword");
            User user = userService.findByUserIdAndUserPassword(userId, userPassword);
            if (user != null) {
                session.setAttribute("userId", user.getUserId());
                model.addAttribute("sessionUserId", user.getUserId());
                return "loginSuccess";  // 로그인 성공 시 홈으로
            } else {
                model.addAttribute("error", "Invalid username or password");
                return "loginFail";   // 로그인 실패 시 페이지로
            }
    	} catch (NumberFormatException e) {
			model.addAttribute("error" , "Invalid user ID format");
			return "loginFail";
		} 
    }

    @GetMapping("/registerForm")
    public String registerForm() {
        return "registerForm";
    }

    @PostMapping("/registerForm")
    public String register(@RequestParam("userName") String userName,
                           @RequestParam("userNickName") String userNickName,
                           @RequestParam("userPassword") String userPassword,
                           @RequestParam("userEmail") String userEmail,
                           @RequestParam("userDomain") String userDomain,
                           @RequestParam("userBirth") @DateTimeFormat(pattern = "yyyy-MM-dd") Date userBirth,
                           @RequestParam("userPhoneNum1") String userPhoneNum1,
                           @RequestParam("userPhoneNum2") String userPhoneNum2,
                           @RequestParam("userPhoneNum3") String userPhoneNum3,
                           @RequestParam("userProfileImage") String userProfileImage,
                           Model model) throws ParseException {

        String userPhoneNum = userPhoneNum1 + "-" + userPhoneNum2 + "-" + userPhoneNum3;
        String fullEmail = userEmail + "@" + userDomain;

        User user = new User();
        user.setUserName(userName);
        user.setUserNickName(userNickName);
        user.setUserPassword(userPassword);
        user.setUserEmail(fullEmail);
        user.setUserDomain(userDomain);
        user.setUserBirth(userBirth);
        user.setUserPhoneNum(userPhoneNum);
        user.setUserProfileImage(userProfileImage);

        userService.registerUser(user);

        return "registerSuccess";
    }

    @PostMapping("/registerForm/json")
    public String registerJson(@RequestBody User user) throws ParseException {
        userService.registerUser(user);
        return "registerSuccess";
    }

    @GetMapping("/registerSuccess")
    public String registerSuccess() {
        return "registerSuccess";
    }
    
    @GetMapping("/{userId}")
    public ResponseEntity<User> getUserId(@PathVariable Long userId) {
    	User user = userService.getUserById(userId);
    	if (user != null) {
    		return ResponseEntity.ok(user);
    	} else {
    		return ResponseEntity.notFound().build();
    	}
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpSession session) {
        if (session != null) {
            session.invalidate();
        }
        return ResponseEntity.ok("로그아웃 성공");
    }

  
}
